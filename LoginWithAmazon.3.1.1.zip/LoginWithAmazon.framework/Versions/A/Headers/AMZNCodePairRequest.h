//
//  AMZNCodePairRequest.h
//  LWAiOSLib
//
//  Created by Van der Elst, Ryan on 6/14/17.
//  Copyright © 2017 Amazon. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "AMZNLWAExchangeRequest.h"

@interface AMZNCodePairRequest : AMZNLWAExchangeRequest

@end
